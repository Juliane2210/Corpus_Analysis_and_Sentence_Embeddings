#!/usr/bin/env python

"""
correlation-noconfidence.py gs system

Outputs the Pearson correlation.

Example:

  $ ./correlation-noconfidence.py gs sys
"""

import sys
import math

if len(sys.argv) != 3:
    print("Usage: {} gs system".format(sys.argv[0]))
    sys.exit(1)

gs_file, sys_file = sys.argv[1], sys.argv[2]

if not (open(gs_file, "r") and open(sys_file, "r")):
    print("Error: One or more input files not found.")
    sys.exit(1)

continue_flag = False
filtered = {}
a, b, c = {}, {}, {}

# Read the first file (gs_file)
with open(gs_file, "r") as f:
    filter_count = 0
    i = 0
    for line in f:
        line = line.strip()
        if not line or line.startswith("#"):
            filter_count += 1
            filtered[filter_count] = 1
        else:
            fields = line.split()
            score = float(fields[0])
            a[i] = score
            i += 1
            filter_count += 1

# Read the second file (sys_file)
j = 0
line_count = 1
with open(sys_file, "r") as f:
    for line in f:
        if line_count not in filtered:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            fields = line.split()
            score, confidence = float(fields[0]), 100
            b[j] = score
            c[j] = confidence
            continue_flag = True
            j += 1
        line_count += 1

if continue_flag:
    sum_w = 0
    sum_wy = 0

    for y in range(i):
        sum_wy += (100 * a[y])
        sum_w += 100
    mean_yw = sum_wy / sum_w

    sum_wx = 0
    for x in range(i):
        sum_wx += (c[x] * b[x])
    mean_xw = sum_wx / sum_w

    sum_wxy = 0
    for x in range(i):
        sum_wxy += c[x] * (b[x] - mean_xw) * (a[x] - mean_yw)
    cov_xyw = sum_wxy / sum_w

    sum_wxx = 0
    for x in range(i):
        sum_wxx += c[x] * (b[x] - mean_xw) * (b[x] - mean_xw)
    cov_xxw = sum_wxx / sum_w

    sum_wyy = 0
    for x in range(i):
        sum_wyy += c[x] * (a[x] - mean_yw) * (a[x] - mean_yw)
    cov_yyw = sum_wyy / sum_w

    corr_xyw = cov_xyw / math.sqrt(cov_xxw * cov_yyw)

    print("Pearson: {:.5f}".format(corr_xyw))
else:
    print("Pearson: N.A.")
    sys.exit(1)
